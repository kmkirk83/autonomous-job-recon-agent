# Outbound Engineering Outreach Templates

## 1. High-Ticket Webhook & Integration Pitch
Subject: Immediate Availability: Full-Stack API Integration & Systems Automation

Hi [Hiring Team / Engineering Lead],

I noticed your current infrastructure requires robust, multi-step API synchronization and end-to-end webhook optimization. I specialize in building closed-loop automation engines, managing custom Linux environments, and deploying dedicated administrative dashboards designed to track multi-project health simultaneously.

Instead of traditional onboarding drag, I operate by pointing directly to functional code footprints. My repositories showcase production-ready pipelines handling complex GraphQL/REST integrations, automated Docker containerization, and low-level system diagnostic logging. 

I am available immediately for a direct technical assessment or sandbox evaluation to help refactor your platform's routing infrastructure this week. Let's connect.

Best regards,  
Kegan Meng  
[GitHub Link Portfolio Asset]

## 2. Technical Recruiter Warm Outreach
Hello [Recruiter Name],

I am reaching out regarding open technical contract pipelines or platform engineering needs within your network. I specialize in bare-metal Linux administration, custom shell automation workflows, and high-velocity workflow automation integrations. I maintain immediate, zero-onboarding-delay availability for advanced systems engineering tasks or technical assessment sandboxes.

Best,  
Kegan Meng