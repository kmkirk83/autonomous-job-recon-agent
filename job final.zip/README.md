# 🛰️ Autonomous Job Recon Agent & Vercel Control Tower

An unsupervised single-turn ReAct automation engine built to process raw web-scraped developer job feeds, execute semantic payload matching against public GitHub footprints, and expose full-stack pipeline logs via a real-time Vercel control center dashboard.

---

### 📊 Real-Time Control Center UI

```
┌────────────────────────────────────────────────────────┐
│ 📊 SYSTEM MONITOR                        STATUS: ONLINE│
├────────────────────────────────────────────────────────┤
│  [Ingestion Vector]   [Active Work Orders]  [Floor Rate]│
│    94.2% Match Rate     Unsupervised (Loop)   $40-$55/hr│
├────────────────────────────────────────────────────────┤
│ Console Logs:                                          │
│ [OK] Inbound Webhook active on /api/webhook            │
│ [INFO] Correlating code against footprint: kyzen/Ralph │
│ [MATCH] 96.8% Target alignment confirmed.              │
└────────────────────────────────────────────────────────┘
```

---

### 🚀 Rapid Deployment Sequence

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure Environment Keys**
   ```bash
   cp .env.local.example .env.local
   # Append your GOOGLE_AI_STUDIO_API_KEY
   ```

3. **Launch Local Server**
   ```bash
   npm run dev
   ```
   Open `http://localhost:3000` inside your browser to monitor the system telemetry logs on the fly!