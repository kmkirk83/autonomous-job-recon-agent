# Technical Summaries & Target Tracks

## 1. Systems Automation & Infrastructure Engineer
High-intellect engineer specializing in bare-metal Linux optimization, full-stack API integration pipelines, and custom administrative dashboard monitoring. Deep background handling local LLM deployments, cross-platform runtime toolkits, and maximizing hardware performance under specific compute constraints. Eliminates operational drag with complete terminal proficiency and custom automation loops. Available for immediate, zero-onboarding-delay deployment into advanced technical evaluation sandboxes.

## 2. Full-Stack Webhook & Integration Architect
Specialist in Next.js, Prisma ORM, and complex GraphQL/REST API bridges. Expert at establishing closed-loop multi-step autonomous execution systems (e.g., integrating Anthropic/Shopify APIs), configuring asynchronous webhook pipelines, and provisioning robust multi-project administrative monitoring consoles.