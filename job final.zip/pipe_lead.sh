#!/bin/bash
if [ -z "$1" ]; then
    echo "❌ Error: Provide path to a text file containing the raw job description listing."
    exit 1
fi

if [ ! -f "$1" ]; then
    echo "❌ Error: Text file not found at path target: $1"
    exit 1
fi

PAYLOAD=$(cat "$1" | sed 's/"/\"/g' | tr '\n' ' ')
echo "🛰️ Transmission initialized to local endpoint pipeline..."
curl -X POST http://localhost:3000/api/webhook \
  -H "Content-Type: application/json" \
  -d "{\"listingText\": \"$PAYLOAD\"}"
echo -e "\n[+] Signal telemetry packet received. Verify matching status inside the console tower."