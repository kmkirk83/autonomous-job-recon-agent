import React from 'react';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: '#0B0E14', color: '#C9D1D9', fontFamily: 'monospace' }}>
        {children}
      </body>
    </html>
  );
}