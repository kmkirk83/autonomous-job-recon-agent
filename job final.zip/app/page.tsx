'use client';
import React, { useState, useEffect } from 'react';

export default function Dashboard() {
  const [logs, setLogs] = useState<string[]>([
    '[SYSTEM] Initializing telemetry channels...',
    '[OK] Webhook API endpoint routing active on /api/webhook',
    '[INFO] Target financial parameters loaded: $40 - $55+/hr floor.',
    '[AWAIT] Awaiting automated incoming payload text buffers...'
  ]);

  return (
    <div style={{ padding: '24px', maxWidth: '1200px', margin: '0 auto' }}>
      <header style={{ borderBottom: '2px solid #1A1F2C', paddingBottom: '12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ color: '#4F46E5', fontSize: '20px', margin: 0 }}>🛰️ JOB RECON AGENT CONTROL TOWER</h1>
        <span style={{ color: '#10B981', fontSize: '14px', fontWeight: 'bold' }}>● SYSTEM ONLINE</span>
      </header>

      <main style={{ marginTop: '24px', display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '20px' }}>
        <section style={{ background: '#111622', padding: '20px', borderRadius: '8px', border: '1px solid #1A1F2C' }}>
          <h2 style={{ fontSize: '16px', color: '#58A6FF', marginTop: 0 }}>Engine Parameters</h2>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '13px' }}>
            <div><strong>Active Contexts:</strong> kyzen, Ralph Loop</div>
            <div><strong>Location Filter:</strong> Simi Valley / Chatsworth / Remote</div>
            <div><strong>Onboarding Hurdle:</strong> Minimum (Skip HR Drag)</div>
          </div>
        </section>

        <section style={{ background: '#111622', padding: '20px', borderRadius: '8px', border: '1px solid #1A1F2C' }}>
          <h2 style={{ fontSize: '16px', color: '#10B981', marginTop: 0 }}>Telemetry Stream Console</h2>
          <div style={{ background: '#010409', border: '1px solid #30363D', borderRadius: '6px', padding: '16px', height: '300px', overflowY: 'auto' }}>
            {logs.map((log, i) => (
              <div key={i} style={{ marginBottom: '8px', fontSize: '13px', lineHeight: '1.5' }}>{log}</div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}